
from collections import Counter
from scapy.all import rdpcap, IP, TCP, UDP
import pandas as pd
import sys

def analyze(pcap_path):
    pkts = rdpcap(pcap_path)
    talkers, ports, protos = Counter(), Counter(), Counter()
    for p in pkts:
        if IP in p:
            talkers[p[IP].src] += 1
            proto = "TCP" if TCP in p else "UDP" if UDP in p else "IP"
            protos[proto] += 1
            if TCP in p:
                ports[p[TCP].dport] += 1
            elif UDP in p:
                ports[p[UDP].dport] += 1

    top_talkers = talkers.most_common(10)
    top_ports   = ports.most_common(10)
    proto_histo = list(protos.items())

    pd.DataFrame(top_talkers, columns=["ip","count"]).to_csv("top_talkers.csv", index=False)
    pd.DataFrame(top_ports,   columns=["port","count"]).to_csv("top_ports.csv", index=False)
    pd.DataFrame(proto_histo, columns=["proto","count"]).to_csv("protocols.csv", index=False)

    print("Top Talkers:", top_talkers)
    print("Top Ports:", top_ports)
    print("Protocols:", proto_histo)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python packet_hunter.py <sample.pcap>")
        sys.exit(1)
    analyze(sys.argv[1])
