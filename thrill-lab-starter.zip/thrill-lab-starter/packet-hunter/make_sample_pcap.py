
from scapy.all import IP, TCP, UDP, ICMP, wrpcap

pkts = []
for i in range(50):
    pkts += [
        IP(src=f"10.0.0.{i%5+2}", dst="93.184.216.34")/TCP(dport=80),
        IP(src=f"10.0.0.{i%5+2}", dst="142.250.183.206")/TCP(dport=443),
        IP(src=f"10.0.0.{i%5+2}", dst="1.1.1.1")/UDP(dport=53),
    ]
for i in range(10):
    pkts += [IP(src="10.0.0.9", dst="129.6.15.28")/UDP(dport=123)]
for i in range(5):
    pkts += [IP(src="10.0.0.7", dst="8.8.8.8")/ICMP()]

wrpcap("sample.pcap", pkts)
print("wrote sample.pcap with", len(pkts), "packets")
