# Packet Hunter 🕵️‍♂️

Analyze network capture files **you legally obtained** (training PCAPs or your own lab).

## Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate
pip install -r ../requirements.txt
```

## Generate a sample PCAP
```bash
python make_sample_pcap.py
```

## Run
```bash
python packet_hunter.py sample.pcap
```

Outputs: `top_talkers.csv`, `top_ports.csv`, `protocols.csv`.
