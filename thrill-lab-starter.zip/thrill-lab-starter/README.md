# Thrill Lab Starter 🚀

Legal, resume-worthy mini-projects for network/security learning.

## Projects
- `packet-hunter/` – analyze PCAP files (top talkers, ports, protocols) and export CSVs.
- `port-scanner/` – fast multi-threaded TCP port scanner with tiny banner grabbing (lab use only).
- `rate-limiter/` – FastAPI app with sliding-window rate limiting + simple load test.

> **Legal note:** Use only on systems you own or have explicit permission to test. No network disruption, jamming, deauth, or targeting of others' assets.
