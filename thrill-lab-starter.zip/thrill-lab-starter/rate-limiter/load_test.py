
import http.client, threading

def hit():
    try:
        c = http.client.HTTPConnection("127.0.0.1", 8000, timeout=2)
        c.request("GET", "/ping")
        r = c.getresponse()
        print(r.status)
    except Exception as e:
        print("err", e)

threads = [threading.Thread(target=hit) for _ in range(60)]
[t.start() for t in threads]
[t.join() for t in threads]
print("done")
