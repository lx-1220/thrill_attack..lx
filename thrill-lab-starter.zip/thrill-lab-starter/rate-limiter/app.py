
from fastapi import FastAPI, Request, HTTPException
from time import time
from collections import defaultdict, deque

app = FastAPI()
WINDOW, MAX_REQ = 10, 30  # 30 requests per 10s
hits = defaultdict(deque)

@app.middleware("http")
async def limiter(request: Request, call_next):
    ip = request.client.host
    now = time()
    dq = hits[ip]
    while dq and now - dq[0] > WINDOW:
        dq.popleft()
    if len(dq) >= MAX_REQ:
        raise HTTPException(status_code=429, detail="Too Many Requests")
    dq.append(now)
    return await call_next(request)

@app.get("/ping")
def ping():
    return {"ok": True}
