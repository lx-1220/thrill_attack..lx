# Rate Limiter 🛡️ (FastAPI)

Sliding-window limiter per IP. Good for protecting your APIs in low-trust environments.

## Run
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r ../requirements.txt
uvicorn app:app --reload
```

## Load Test (simple)
```bash
python load_test.py
```
