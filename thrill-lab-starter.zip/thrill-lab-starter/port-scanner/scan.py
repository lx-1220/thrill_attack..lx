
import socket, argparse, concurrent.futures
from rich.progress import track

def check(host, port, timeout=0.3):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(timeout)
        try:
            s.connect((host, port))
            banner = ""
            try:
                s.sendall(b"HEAD / HTTP/1.0\r\n\r\n")
                banner = s.recv(64).decode(errors="ignore").strip()
            except Exception:
                pass
            return port, True, banner
        except Exception:
            return port, False, ""

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", required=True)
    ap.add_argument("--ports", default="1-1024")
    ap.add_argument("--threads", type=int, default=200)
    args = ap.parse_args()

    start, end = [int(x) for x in args.ports.split("-")]
    ports = list(range(start, end+1))
    openp = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.threads) as ex:
        for port, ok, banner in track(ex.map(lambda p: check(args.host, p), ports), total=len(ports)):
            if ok:
                openp.append((port, banner))

    print("Open ports:")
    for p, b in openp:
        print(f"{p}\t{b[:60]}")
