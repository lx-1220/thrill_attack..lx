# Port Scanner ⚡

Fast multi-threaded TCP scanner with tiny banner probing. **Use only on hosts you own or have permission to test.**

## Run
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r ../requirements.txt
python scan.py --host 127.0.0.1 --ports 1-2000 --threads 200
```
